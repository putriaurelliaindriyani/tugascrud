<?php
if(isset($_GET['kode'])){
   include "koneksi.php";

   $kode = $_GET['kode'];
   $sql = "DELETE FROM input WHERE kode_produk='$kode'";
   $kueri = mysqli_query($koneksi, $sql);
   if($kueri){
    echo "<script>alert('Data barang berhasil dihapus');document.location='tabel.php'</script>";
   } else{
   echo "<script>alert('Data barang Gagal dihapus');document.location='tabel.php'</script>";
   }
} else {

    echo "<script>alert('Kode Barang Belum Dipilih');document.location='tabel.php'</script>";
}
?>