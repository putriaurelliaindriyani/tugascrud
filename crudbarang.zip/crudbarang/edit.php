<?php
  include "koneksi.php";
if(isset($_GET['kode'])){
   $kode = $_GET['kode'];
} else {
    //kalo gak ada  parameternya
    echo "<script>alert('Kode Barang Belum Dipilih');document.location='form.php'</script>";
}

   $sql = "SELECT * FROM input WHERE kode_produk='$kode'";
   $kueri = mysqli_query($koneksi, $sql);
   $data = mysqli_fetch_array($kueri);

    $Nama_produk = $data['nama_produk'];
    $Harga_produk = $data['harga_produk'];
    $Satuan_produk = $data['satuan'];
    $Kategori_produk = $data['kategori'];
    $Stok_produk = $data['stock'];
    $Gambar_produk = $data['gambar'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <title>Document</title> 

<style>
    
    .container{
        border: 1px solid black;
        width: 500px;
        margin-left: 450px;
        text-align: left;
    }
    .tabledata{
        width: 10 px;
        margin-left: 367px;
    }
   
    .bg {
        background: red;
        color: white
    }

    .red {
        background: red;
        color: white
    }
</style>
</head>
<body>
<div class="container">
<form action="" method="post" name="frmbarang" onsubmit="return cekform()">
        <table class="table">
            <h4 style="text-align: center">FORM INPUT MASTER DAN STOCK DATA BARANG</h4>
            <tr>
                <td>Kode Produk</td>
                <td id="kode"name="kode"></td>
            </tr>
            <tr>
                <td>Nama Produk</td>
                <td><input type="text"name="nama" id="nama"value="<?php echo $Nama_produk?>"></td>
            </tr>
            <tr>
                <td>Harga Produk</td>
                <td><input type="Number" name="harga" value="" id="harga"value="<?php echo $Harga_produk?>"></td>
            </tr>
            <tr>
                <td>Satuan</td>
                <td>
                    <select name="satuan" id="satuan"value="<?php echo $Satuan_produk?>">
                        <option value="">Pilih Satuan</option>
                        <option value="Gelas">Gelas</option>
                        <option value="piring">piring</option>
                        <option value="mangkok">mangkok</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Kategori</td>
                <td>
                    <select name="kategori" id="kategori"value="<?php echo $Kategori_produk?>">
                        <option value="">Pilih Kategori</option>
                        <option value="Dingin">Dingin</option>
                        <option value="Hangat">Panas</option>
                        <option value="Panas">Hangat</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Url Gambar</td>
                <td><input type="text"name="gambar" id="gambar"value="<?php echo $Gambar_produk?>"></td>
            </tr>
            <tr>
                <td>Stok Awal</td>
                <td><input type="Number"name="stok" value="" id="stok"value="<?php echo $Stok_produk?>"></td>
            </tr>
            <tr>
                <td>
                <input name="edit" type="submit" id="edit" value="Edit Barang" />
                   
                </td>
            </tr>
        </table>
        </form>
    </div>
</body>
</html>
<?php

if(isset($_POST['edit'])){
    
    $Nama_produk = $_POST['nama'];
    $Harga_produk = $_POST['harga'];
    $Satuan_produk = $_POST['satuan'];
    $Kategori_produk = $_POST['kategori'];
    $Gambar_produk = $_POST['gambar'];
    $Stok_produk = $_POST['stok'];
   
    
    $sql = "UPDATE input SET nama_produk='$Nama_produk', harga_produk='$Harga_produk',satuan ='$Satuan_produk',kategori ='$Kategori_produk',gambar ='$Gambar_produk',stock ='$Stok_produk' WHERE kode_produk='$kode'";
 
    $kueri = mysqli_query($koneksi, $sql);
   
    if($kueri){
        echo "<script>alert('Data barang berhasil diedit'); document.location='tabel.php'</script>";
    } else {
        echo "<script>alert('Data barang gagal diedit')</script>";
        //tampilkan pesan error mysqlnya
        echo mysqli_error();
    }
}

?>