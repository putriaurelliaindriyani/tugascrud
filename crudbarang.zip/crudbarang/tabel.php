<?php
include 'koneksi.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
     <style>
     table{
         width :840px;
         margin : auto;
     }


</style>

</head>
<body>
<table class="tabledata" cellspacing='0' border="1" >

<a href ="form.php"> input barang</a>


<tr>

              
               <td>kode Produk</td>
                <td>Nama Produk</td>
                <td>Harga Produk</td>
                <td>Satuan Produk</td>
                <td>Kategori Produk</td>
                <td>Gambar Produk</td>
                <td>Stok Produk</td>
                <td>Modify</td>
</tr>
     
<?php
                $sql = "SELECT * FROM `input`";
              $query = mysqli_query ($koneksi,$sql);
             while($data = mysqli_fetch_array($query)){
                 $no = 1;
                ?>
                <tr>
                   
                    <td><?php echo $data['kode_produk']?></td>
                    <td><?php echo $data['nama_produk']?></td>
                    <td><?php echo $data['harga_produk'];?></td>
                    <td><?php echo $data['satuan']?></td>
                    <td><?php echo $data['kategori']?></td>
                    <td><?php echo $data['gambar']?></td>
                    <td><?php echo $data['stock']?></td>

                <td><a href="edit.php?kode=<?php echo $data['kode_produk']?>">Edit</a> 
                </td><td><a href="hapus.php?kode=<?php echo $data['kode_produk']?>">Delete</a></td>
                </tr>
                <?php
            
        }
      
            ?>

</table>
    
</body>
</html>