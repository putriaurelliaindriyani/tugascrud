<?php

$DB_HOST     = "localhost";
$DB_USERNAME = "root";
$DB_PASSWORD = "";
$DB_DATABASE = "crud";


//buat koneksi
$koneksi = new mysqli($DB_HOST, $DB_USERNAME, $DB_PASSWORD, $DB_DATABASE);

//cek koneksi
if($koneksi->connect_error) {
    die('koneksi gagal: ' .$koneksi->connect_error);
}
?>