<?php include ("koneksi.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        
        .container{
            border: 1px solid black;
            width: 500px;
            margin-left: 450px;
            text-align: left;
        }
        .tabledata{
            width: 10 px;
            margin-left: 367px;
        }
       
        .bg {
            background: red;
            color: white
        }

        .red {
            background: red;
            color: white
        }
    </style>
</head>
<body>
 
    <div class="container">
    <form action="" method="post" name="frmbarang" onsubmit="return cekform()">
        <table class="table">
            <h4 style="text-align: center">FORM INPUT MASTER DAN STOCK DATA BARANG</h4>
            <tr>
                <td>Kode Produk</td>
                <td id="kode" name="kode"></td>
            </tr>
            <tr>
                <td>Nama Produk</td>
                <td><input type="text" id="nama" name="nama"></td>
            </tr>
            <tr>
                <td>Harga Produk</td>
                <td><input type="Number" value="" id="harga" name="harga"></td>
            </tr>
            <tr>
                <td>Satuan</td>
                <td>
                    <select name="satuan" id="satuan">
                        <option value="">Pilih Satuan</option>
                        <option value="Gelas">Gelas</option>
                        <option value="piring">piring</option>
                        <option value="mangkok">mangkok</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Kategori</td>
                <td>
                    <select name="kategori" id="kategori">
                        <option value="">Pilih Kategori</option>
                        <option value="Dingin">Dingin</option>
                        <option value="Hangat">Panas</option>
                        <option value="Panas">Hangat</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Url Gambar</td>
                <td><input type="text" id="gambar" name="gambar"></td>
            </tr>
            <tr>
                <td>Stok Awal</td>
                <td><input type="Number" value="" id="stok" name="stok"></td>
            </tr>
            <tr>
                <td>
                   <input type ="submit" value ="masuk" name = "masuk"/>
                   <a href ="tabel.php">Daftar barang </a>
                </td>
              

        
            </tr>
        </table>
        </form>
    </div>
</body>
</html>
<?php

include "koneksi.php";

if(isset($_POST['masuk'])){
    $Nama_produk = $_POST['nama'];
    $Harga_produk = $_POST['harga'];
    $Satuan_produk = $_POST['satuan'];
    $Kategori_produk = $_POST['kategori'];
    $Gambar_produk = $_POST['gambar'];
    $Stok_produk = $_POST['stok'];
   

     $sql ="INSERT INTO `input` (`kode_produk`, `nama_produk`, `harga_produk`, `satuan`, `kategori`, `gambar`, `stock`)
      VALUES (NULL, '$Nama_produk', ' $Harga_produk', '$Satuan_produk ', ' $Kategori_produk', ' $Gambar_produk', ' $Stok_produk')";
     $query = mysqli_query($koneksi,$sql);
        
    
    if($query){
  
        echo "<script>alert('Data barang berhasil dimasukkan ke database')</script>";
    } else {
    
        echo "<script>alert('Data barang gagal dimasukkan ke database')</script>";
        
      
    }
}
?>